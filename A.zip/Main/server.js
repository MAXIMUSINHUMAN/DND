const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const app = express();
const port = 3000;

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Form parser
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use('/CAT', express.static(path.join(__dirname, 'CAT')));

// Utility function to read JSON
function readJsonFile(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

// Helper for creating directories safely
function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

// -------------------------------
// Multer setup for Add Post
// -------------------------------

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Extract folder info from body
    const { category, newCategory, subcategory, newSubcategory, folderName } = req.body;
    const finalCategory = newCategory && newCategory.trim() !== '' ? newCategory.trim() : category;
    const finalSubcategory = newSubcategory && newSubcategory.trim() !== '' ? newSubcategory.trim() : subcategory;
    const postFolder = path.join(__dirname, 'CAT', finalCategory, finalSubcategory, folderName);

    // Ensure folders exist
    ensureDir(postFolder);
    ensureDir(path.join(postFolder, 'THUMB'));
    ensureDir(path.join(postFolder, 'IMGS'));
    ensureDir(path.join(postFolder, 'VIDS'));

    // Choose folder based on file type
    let dest = postFolder;
    if (file.fieldname === 'thumbnail') dest = path.join(postFolder, 'THUMB');
    if (file.fieldname === 'images') dest = path.join(postFolder, 'IMGS');
    if (file.fieldname === 'videos') dest = path.join(postFolder, 'VIDS');

    cb(null, dest);
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); // keep original filename
  }
});

const upload = multer({ storage });

// -------------------------------
// Routes
// -------------------------------

// Home Page
app.get('/', (req, res) => {
  const categories = fs.readdirSync(path.join(__dirname, 'CAT'))
    .filter(file => fs.statSync(path.join(__dirname, 'CAT', file)).isDirectory());
  res.render('index', { categories });
});

// Subcategory Page
app.get('/category/:categoryName', (req, res) => {
  const { categoryName } = req.params;
  const subcategories = fs.readdirSync(path.join(__dirname, 'CAT', categoryName))
    .filter(file => fs.statSync(path.join(__dirname, 'CAT', categoryName, file)).isDirectory());
  res.render('subcategory', { categoryName, subcategories });
});

// Post List Page
app.get('/category/:categoryName/:subcategoryName', (req, res) => {
  const { categoryName, subcategoryName } = req.params;

  const posts = fs.readdirSync(path.join(__dirname, 'CAT', categoryName, subcategoryName))
    .filter(file => fs.statSync(path.join(__dirname, 'CAT', categoryName, subcategoryName, file)).isDirectory());

  const postDetails = posts.map(post => {
    const dataPath = path.join(__dirname, 'CAT', categoryName, subcategoryName, post, 'data.json');
    const detailsPath = path.join(__dirname, 'CAT', categoryName, subcategoryName, post, 'details.json');
    const data = readJsonFile(dataPath);
    const details = readJsonFile(detailsPath);

    const thumbFiles = fs.readdirSync(path.join(__dirname, 'CAT', categoryName, subcategoryName, post, 'THUMB'));
    const thumb = thumbFiles.length > 0 ? thumbFiles[0] : null;

    return { post, data, details, thumb };
  });

  res.render('postlist', { categoryName, subcategoryName, postDetails });
});

// Post Page
app.get('/category/:categoryName/:subcategoryName/:postName', (req, res) => {
  const { categoryName, subcategoryName, postName } = req.params;

  const data = readJsonFile(path.join(__dirname, 'CAT', categoryName, subcategoryName, postName, 'data.json'));
  const details = readJsonFile(path.join(__dirname, 'CAT', categoryName, subcategoryName, postName, 'details.json'));

  const images = fs.readdirSync(path.join(__dirname, 'CAT', categoryName, subcategoryName, postName, 'IMGS'));
  const videos = fs.readdirSync(path.join(__dirname, 'CAT', categoryName, subcategoryName, postName, 'VIDS'));

  const folderPath = path.join(__dirname, 'CAT', categoryName, subcategoryName, postName);

  res.render('post', {
    categoryName,
    subcategoryName,
    postName,
    data,
    details,
    images,
    videos,
    folderPath
  });
});

// Search Page
app.get('/search', (req, res) => {
  const query = req.query.query ? req.query.query.trim().toLowerCase() : '';

  if (!query) return res.redirect('/');

  const categories = fs.readdirSync(path.join(__dirname, 'CAT'))
    .filter(file => fs.statSync(path.join(__dirname, 'CAT', file)).isDirectory());

  let searchResults = [];

  categories.forEach(categoryName => {
    const subcategories = fs.readdirSync(path.join(__dirname, 'CAT', categoryName))
      .filter(file => fs.statSync(path.join(__dirname, 'CAT', categoryName, file)).isDirectory());

    subcategories.forEach(subcategoryName => {
      const posts = fs.readdirSync(path.join(__dirname, 'CAT', categoryName, subcategoryName))
        .filter(file => fs.statSync(path.join(__dirname, 'CAT', categoryName, subcategoryName, file)).isDirectory());

      posts.forEach(postName => {
        const data = readJsonFile(path.join(__dirname, 'CAT', categoryName, subcategoryName, postName, 'data.json'));
        const details = readJsonFile(path.join(__dirname, 'CAT', categoryName, subcategoryName, postName, 'details.json'));

        if (
          data.Name.toLowerCase().includes(query) ||
          data.ID.toLowerCase().includes(query) ||
          details.Description.toLowerCase().includes(query) ||
          details.Tags.some(t => t.toLowerCase().includes(query))
        ) {
          const thumbFiles = fs.readdirSync(path.join(__dirname, 'CAT', categoryName, subcategoryName, postName, 'THUMB'));
          const thumb = thumbFiles.length > 0 ? thumbFiles[0] : null;

          searchResults.push({
            categoryName,
            subcategoryName,
            postName,
            data,
            details,
            thumb
          });
        }
      });
    });
  });

  res.render('searchresults', {
    query,
    searchResults,
    message: searchResults.length === 0 ? 'No results found.' : null
  });
});

// -------------------------------
// Add Post GET
// -------------------------------
app.get('/add', (req, res) => {
  const categories = fs.readdirSync(path.join(__dirname, 'CAT'))
    .filter(file => fs.statSync(path.join(__dirname, 'CAT', file)).isDirectory());

  let subcategories = [];

  categories.forEach(cat => {
    const subs = fs.readdirSync(path.join(__dirname, 'CAT', cat))
      .filter(file => fs.statSync(path.join(__dirname, 'CAT', cat, file)).isDirectory());

    subcategories.push(...subs);
  });

  res.render('add', { categories, subcategories });
});

// -------------------------------
// Add Post POST
// -------------------------------
app.post('/add', upload.fields([
  { name: 'thumbnail', maxCount: 1 },
  { name: 'images', maxCount: 50 },
  { name: 'videos', maxCount: 50 }
]), (req, res) => {

  const {
    category,
    newCategory,
    subcategory,
    newSubcategory,
    folderName,
    postName,
    description,
    tags,
    links,
    status
  } = req.body;

  const finalCategory = newCategory && newCategory.trim() !== '' ? newCategory.trim() : category;
  const finalSubcategory = newSubcategory && newSubcategory.trim() !== '' ? newSubcategory.trim() : subcategory;

  if (!finalCategory || !finalSubcategory || !folderName || !postName) {
    return res.status(400).send('Category, Subcategory, Folder Name and Post Name are required.');
  }

  const postFolder = path.join(__dirname, 'CAT', finalCategory, finalSubcategory, folderName);
  ensureDir(postFolder);
  ensureDir(path.join(postFolder, 'THUMB'));
  ensureDir(path.join(postFolder, 'IMGS'));
  ensureDir(path.join(postFolder, 'VIDS'));

  const autoID = "ID" + Date.now();

  const dataJson = {
    Name: postName,
    ID: autoID,
    status: status || "y"
  };

  const tagsArray = tags ? tags.split(/[\n,]/).map(t => t.trim()).filter(t => t) : [];
  const linksArray = links ? links.split(/[\n,]/).map(l => l.trim()).filter(l => l) : [];

  const detailsJson = {
    Description: description || "",
    Tags: tagsArray,
    Links: linksArray
  };

  fs.writeFileSync(path.join(postFolder, 'data.json'), JSON.stringify(dataJson, null, 2));
  fs.writeFileSync(path.join(postFolder, 'details.json'), JSON.stringify(detailsJson, null, 2));

  // No need to move files manually now; Multer already saved them in correct folders

  res.redirect(`/category/${finalCategory}/${finalSubcategory}/${folderName}`);
});

// -------------------------------------------
// Start Server
// -------------------------------------------
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
